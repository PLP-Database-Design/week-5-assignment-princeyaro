-- 1.1). Add a new patient with the following details
INSERT INTO patients (first_name, second_name, date_of_birth, gender, language)
VALUES ('John', 'Doe', '1980-11-15', 'Male', 'English');


-- 2.1). Write a query to change John Doe's language from "English" to "Spanish"
UPDATE patients
SET language = 'Spanish'
WHERE first_name = 'John' AND second_name = 'Doe';


-- 3.1). Delete the patient with the patient_id number 10
DELETE FROM patients
WHERE patient_id = 10;


-- 4.1). Write a query to find all the names and emails of the providers and if any of them has a NULL email, replace it with N/A
SELECT name, COALESCE(email, 'N/A') AS email
FROM providers;

-- 4.2). Write a query that takes the names and contact details of the provider whether phone number or email and if any of the two is missing, replace it with "Missing details"
SELECT name, 
       COALESCE(phone_number, 'Missing details') AS phone_number, 
       COALESCE(email, 'Missing details') AS email
FROM providers;

-- Bonus question
-- Write a query to retrieve all providers whose specialty is pediatrics and they are missing either of the contact details.
SELECT name
FROM providers
WHERE specialty = 'pediatrics' 
  AND (phone_number IS NULL OR email IS NULL);