var mysql = require('mysql');

var connection = mysql.createConnection({
    host: 'localhost',
    database: 'healthcare_db',
    user: 'root',
    password: 'Nu66et'

});

module.exports = connection;